<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\TeleSalesAgent;
use App\Models\Company\CompanyProfile;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Response;

class TsmAgent extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'tsm:agent';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {


    $agentsData = [
    ['Shafaq', 'Naz', 'Shafaq.Naz.tsm.2026', 'Shafaq#Naz#tsm#2026', 'HD1595'],
    ['Maria', 'Malik', 'Maria.Malik.tsm.2026', 'Maria#Malik#tsm#2026', 'HD1596'],
    ['Muhammad Shoaib', 'Akram', 'MuhammadShoaib.Akram.tsm.2026', 'Muhammad Shoaib#Akram#tsm#2026', 'HD1597'],
    ['Aamina', 'Bibi', 'Aamina.Bibi.tsm.2026', 'Aamina#Bibi#tsm#2026', 'HD1598'],
    ['Amina', 'Azam', 'Amina.Azam.tsm.2026', 'Amina#Azam#tsm#2026', 'HD1599'],
    ['Hamna', 'Tariq', 'Hamna.Tariq.tsm.2026', 'Hamna#Tariq#tsm#2026', 'HD1600'],
    ['Insha', 'Farid', 'Insha.Farid.tsm.2026', 'Insha#Farid#tsm#2026', 'HD1601'],
    ['Areeba', 'Kiran', 'Areeba.Kiran.tsm.2026', 'Areeba#Kiran#tsm#2026', 'HD1602'],
    ['Fakhar', 'Un Nisa', 'Fakhar.UnNisa.tsm.2026', 'Fakhar#Un Nisa#tsm#2026', 'HD1603'],
    ['Muhammad Naeem', 'Khan', 'MuhammadNaeem.Khan.tsm.2026', 'Muhammad Naeem#Khan#tsm#2026', 'HD1604'],
    ['Eman', 'Tariq', 'Eman.Tariq.tsm.2026', 'Eman#Tariq#tsm#2026', 'HD1605'],
];





        foreach ($agentsData as $data) {
            $request = [
                'first_name' => $data[0],
                'last_name' => $data[1],
                'username' => $data[2],
                'emp_code' => $data[4],
                'status' => 1,
                'company_id' => 11,
                'password' => $data[3],
                'email' => strtolower($data[2]) . '@gmail.com',  // Using username for the email
            ];

            // Validation
            $validator = Validator::make($request, [
                'first_name' => 'required',
                'last_name' => 'required',
                'username' => 'required|unique:tele_sales_agents',
                'email' => 'required|email|unique:tele_sales_agents',
                'status' => 'required|in:1,0',
                'company_id' => 'required',
                'password' => 'required|min:6',
                'emp_code' => 'required',
            ]);

            if ($validator->fails()) {
                $this->error("Validation failed for: " . $request['username']);
                continue;
            }

            // Creating the telesales agent record
            TeleSalesAgent::create([
                'first_name' => $request['first_name'],
                'last_name' => $request['last_name'],
                'username' => $request['username'],
                'email' => $request['email'],
                'status' => $request['status'],
                'company_id' => $request['company_id'],
                'password' => Hash::make($request['password']),
                'islogin' => 0,
                'call_status' => 0,
                'today_login_time' => now(),
                'today_logout_time' => now(),
                'emp_code' => $request['emp_code'],
            ]);

            $this->info("Created Telesales Agent: " . $request['username']);
        }

        return 0;
    }
}
