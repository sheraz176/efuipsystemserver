<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\TeleSalesAgent;
use App\Models\Company\CompanyProfile;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Response;

class basicAgentCreate extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'basicagent:create';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Basic Agent Ids Create';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {

$agentsData = [
    ['Ayesha', 'Bibi', 'ayesha.bibi.abacus', 'Ayesha#Bibi##abacus#2026', 'ayeshabibi@example.com'],
    ['Iqra', 'Kafeel', 'iqra.kafeel.abacus', 'Iqra#Kafeel##abacus#2026', 'iqrakafeel@example.com'],
    ['Sheeba', 'Zahid', 'sheeba.zahid.abacus', 'Sheeba#Zahid##abacus#2026', 'sheebazahid@example.com'],
    ['Alishba', 'Anees', 'alishba.anees.abacus', 'Alishba#Anees##abacus#2026', 'alishbaanees@example.com'],
    ['Tayyaba', 'Arshad', 'tayyaba.arshad.abacus', 'Tayyaba#Arshad##abacus#2026', 'tayyabaarshad@example.com'],
    ['Atika', 'Salamat', 'atika.salamat.abacus', 'Atika#Salamat##abacus#2026', 'atikasalamat@example.com'],
    ['Maria', 'Khalid', 'maria.khalid.abacus', 'Maria#Khalid##abacus#2026', 'mariakhalid@example.com'],
    ['Mirab', 'Yousaf', 'mirab.yousaf.abacus', 'Mirab#Yousaf##abacus#2026', 'mirabyousaf@example.com'],
    ['Azka', 'Younas', 'azka.younas.abacus', 'Azka#Younas##abacus#2026', 'azkayounas@example.com'],
    ['Esha', 'Nadeem', 'esha.nadeem.abacus', 'Esha#Nadeem##abacus#2026', 'eshanadeem@example.com'],
    ['Sherish', 'Sharafat', 'sherish.sharafat.abacus', 'Sherish#Sharafat##abacus#2026', 'sherishsharafat@example.com'],
    ['Bisma', 'Batool', 'bisma.batool.abacus', 'Bisma#Batool##abacus#2026', 'bismabatool@example.com'],
    ['Roshan', 'Rasool', 'roshan.rasool.abacus', 'Roshan#Rasool##abacus#2026', 'roshanrasool@example.com'],
    ['Malaika', 'Shahid', 'malaika.shahid.abacus', 'Malaika#Shahid##abacus#2026', 'malaikashahid@example.com'],
];


        foreach ($agentsData as $data) {
            $request = [
                'first_name' => $data[0],
                'last_name' => $data[1],
                'username' => $data[2],
                'email' => $data[4],
                'status' => 1,
                'company_id' => 2,
                'password' => $data[3],
            ];

            $validator = Validator::make($request, [
                'first_name' => 'required',
                'last_name' => 'required',
                'username' => 'required|unique:tele_sales_agents',
                'email' => 'required|email|unique:tele_sales_agents',
                'status' => 'required|in:1,0',
                'company_id' => 'required',
                'password' => 'required|min:6',
            ]);

            if ($validator->fails()) {
                $this->error("Validation failed for: " . $request['username']);
                continue;
            }

            $validatedData = $validator->validated();
            $validatedData['islogin'] = 0;
            $validatedData['call_status'] = false;
            $validatedData['password'] = Hash::make($request['password']);
            $validatedData['today_login_time'] = now();
            $validatedData['today_logout_time'] = now();

            TelesalesAgent::create($validatedData);

            $this->info("Created Telesales Agent: " . $request['username']);
        }

        return 0;
    }
}
