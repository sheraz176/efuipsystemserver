<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Response;

class downloadagent extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'download:agent';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
{


$agentsData = [
    ['Ayeshat', 'Bibi2', 'ayesha.bibi2.abacus', 'Ayesha#Bibi#abacus#2026', 'ayeshabibi2@gmail.com'],
    ['Iqra', 'Kafeel', 'iqra.kafeel.abacus', 'Iqra#Kafeel##abacus#2026', 'iqrakafeel@example.com'],
    ['Sheeba', 'Zahid', 'sheeba.zahid.abacus', 'Sheeba#Zahid##abacus#2026', 'sheebazahid@example.com'],
    ['Alishba', 'Anees', 'alishba.anees.abacus', 'Alishba#Anees##abacus#2026', 'alishbaanees@example.com'],
    ['Tayyabt', 'Arshad2', 'tayyaba2.arshad.abacus', 'Tayyaba#Arshad#abacus#2026', 'tayyabaarshad2@gmail.com'],
    ['Atika', 'Salamat', 'atika.salamat.abacus', 'Atika#Salamat##abacus#2026', 'atikasalamat@example.com'],
    ['Maria', 'Khalid', 'maria.khalid.abacus', 'Maria#Khalid##abacus#2026', 'mariakhalid@example.com'],
    ['Mirab', 'Yousaf', 'mirab.yousaf.abacus', 'Mirab#Yousaf##abacus#2026', 'mirabyousaf@example.com'],
    ['Azka', 'Younas', 'azka.younas.abacus', 'Azka#Younas##abacus#2026', 'azkayounas@example.com'],
    ['Esha', 'Nadeem', 'esha.nadeem.abacus', 'Esha#Nadeem##abacus#2026', 'eshanadeem@example.com'],
    ['Sherish', 'Sharafat', 'sherish.sharafat.abacus', 'Sherish#Sharafat##abacus#2026', 'sherishsharafat@example.com'],
    ['Bisma', 'Batool', 'bisma.batool.abacus', 'Bisma#Batool##abacus#2026', 'bismabatool@example.com'],
    ['Roshan', 'Rasool', 'roshan.rasool.abacus', 'Roshan#Rasool##abacus#2026', 'roshanrasool@example.com'],
    ['Malaika', 'Shahid', 'malaika.shahid.abacus', 'Malaika#Shahid##abacus#2026', 'malaikashahid@example.com'],
];



    $headers = ['First Name', 'Last Name', 'Username', 'Password','email'];

    // CSV File Generation
    $filePath = storage_path('app/agents.csv');
    $file = fopen($filePath, 'w');
    fputcsv($file, $headers);

    foreach ($agentsData as $agent) {
        fputcsv($file, $agent);
    }

    fclose($file);

    // Output a success message
    $this->info('CSV file created successfully at ' . $filePath);

    return 0; // Exit code 0 indicates success
}

}
