<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Subscription\CustomerSubscription;
use App\Models\RecusiveChargingData;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\JsonResponse;

class RecusiveCharging extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'recusive:charging';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {

        try {
            // Get today's date in 'YYYY-MM-DD' format
            $today = Carbon::now()->toDateString();

            // Query subscriptions with recursive charging date due today and policy_status = 1
            $subscriptions = DB::table('customer_subscriptions')
                ->select('subscription_id', DB::raw("CONCAT('92', SUBSTRING(subscriber_msisdn, -10)) AS subscriber_msisdn"), 'transaction_amount', 'consecutiveFailureCount', 'recursive_charging_date', 'product_duration', 'plan_id', 'productId')
                ->whereDate('recursive_charging_date', $today)
                ->where('policy_status', 1)->whereIn('transaction_amount',[4, 133])
                ->get();
            // dd($subscriptions);
            // Iterate over subscriptions
            foreach ($subscriptions as $subscription) {
                try {
                    // Make payment gateway request
                    $paymentResponse = $this->makePaymentGatewayRequest($subscription->subscriber_msisdn, $subscription->transaction_amount);

                    // Process payment response
                    if ($paymentResponse['resultCode'] === "0") {
                        // Calculate next charging date
                        $nextChargingDate = Carbon::parse($subscription->recursive_charging_date)->addDays($subscription->product_duration)->toDateString();

                        // Update database records
                        DB::table('customer_subscriptions')
                            ->where('subscription_id', $subscription->subscription_id)
                            ->update([
                                'recursive_charging_date' => $nextChargingDate,
                                'consecutiveFailureCount' => 0
                            ]);

                        // Insert payment data into recusive_charging_data table
                        DB::table('recusive_charging_data')->insert([
                            'subscription_id' => $subscription->subscription_id,
                            'tid' => $paymentResponse['transactionId'] ?? null,
                            'reference_id' => $paymentResponse['referenceId'] ?? null,
                            'amount' => $paymentResponse['amount'] ?? null,
                            'plan_id' => $subscription->plan_id,
                            'product_id' => $subscription->productId,
                            'cps_response' => $paymentResponse['resultDesc'] ?? $paymentResponse['failedReason'] ?? null,
                            'charging_date' => $paymentResponse['timeStamp'] ?? null,
                            'customer_msisdn' => $subscription->subscriber_msisdn,
                            'duration' => $subscription->product_duration,
                            'created_at' => now(),
                            'updated_at' => now()
                        ]);
                    } else {
                        // Increment consecutive failure count
                        DB::table('customer_subscriptions')
                            ->where('subscription_id', $subscription->subscription_id)
                            ->increment('consecutiveFailureCount');

                        // Update policy status if consecutive failure count reaches 6
                        if ($subscription->consecutiveFailureCount === 6) {
                            DB::table('customer_subscriptions')
                                ->where('subscription_id', $subscription->subscription_id)
                                ->update(['policy_status' => 0]);
                        }

                        // Insert payment data into recusive_charging_data table
                        DB::table('recusive_charging_data')->insert([
                            'subscription_id' => $subscription->subscription_id,
                            'tid' => $paymentResponse['transactionId'] ?? null,
                            'reference_id' => $paymentResponse['referenceId'] ?? null,
                            'amount' => $paymentResponse['amount'] ?? null,
                            'plan_id' => $subscription->plan_id,
                            'product_id' => $subscription->productId,
                            'cps_response' => $paymentResponse['resultDesc'] ?? $paymentResponse['failedReason'] ?? null,
                            'charging_date' => $paymentResponse['timeStamp'] ?? null,
                            'customer_msisdn' => $subscription->subscriber_msisdn,
                            'duration' => $subscription->product_duration,
                            'created_at' => now(),
                            'updated_at' => now()
                        ]);
                    }
                } catch (\Exception $error) {
                    // Handle individual subscription processing error
                    throw new \Exception('Error processing subscription: ' . $error->getMessage());
                }
            }

            return response()->json(['success' => true, 'message' => 'Recursive charging checked successfully']);
        } catch (\Exception $error) {
            // Handle main checkRecursiveCharging method error
            return response()->json(['success' => false, 'message' => $error->getMessage()], 500);
        }



        return 0;
    }

     function makePaymentGatewayRequest($msisdn, $amount) {
        try {
          // Generate a unique reference ID
          $referenceId = mt_rand(100000000000000000, 999999999999999999);

          // Construct the request data
          $requestData = [
              'accountNumber' => $msisdn,
              'amount' => $amount,
              'referenceId' => $referenceId,
              'type' => 'autoPayment',
              'merchantName' => 'KFC',
              'merchantID' => '10254',
              'merchantCategory' => 'Cellphone',
              'merchantLocation' => 'Khaadi F-8',
              'POSID' => '12312',
              'Remark' => 'This is test Remark',
              'ReservedField1' => '',
              'ReservedField2' => '',
              'ReservedField3' => '',
          ];

          // Encrypt the request data (You need to implement this function)
          $encryptedRequestData = $this->encryptData(json_encode($requestData));

          // Set up the request parameters
          $url = 'https://gateway.jazzcash.com.pk/jazzcash/third-party-integration/rest/api/wso2/v1/insurance/sub_autoPayment';
          $headers = [
              'X-CLIENT-ID' => '946658113e89d870aad2e47f715c2b72',
              'X-CLIENT-SECRET' => 'e5a0279efbd7bd797e472d0ce9eebb69',
              'X-PARTNER-ID' => '946658113e89d870aad2e47f715c2b72',
              'Content-Type' => 'application/json',
          ];

          // Make the API request
          $response = Http::withHeaders($headers)->post($url, ['data' => $encryptedRequestData]);

          $responseData = $response->json();
        //   dd($responseData);
          // Decrypt the response data (You need to implement this function)
          $decryptedResponseData = $this->decryptData($responseData['data']);

          $this->info('Payment Successful.');
          $this->info('Response data: ' . print_r($decryptedResponseData, true));
      } catch (\Exception $error) {
          $this->error('Error making payment gateway API request: ' . $error->getMessage());
      }
        }

        private function encryptData($data)
    {
        $key = 'mYjC!nc3dibleY3k';
        $iv = 'Myin!tv3ctorjCM@';
        return openssl_encrypt($data, 'AES-128-CBC', $key, 0, $iv);
    }

    /**
     * Function to decrypt data using AES-128-CBC.
     *
     * @param string $data
     * @return string
     */
    private function decryptData($data)
    {
        $key = 'mYjC!nc3dibleY3k';
        $iv = 'Myin!tv3ctorjCM@';
        return openssl_decrypt($data, 'AES-128-CBC', $key, 0, $iv);
    }


}
