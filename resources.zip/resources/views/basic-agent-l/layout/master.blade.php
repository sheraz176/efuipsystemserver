
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Zindigi Portal</title>

    <meta name="description" content="" />
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="{{ asset('newdes/icon.png') }}" />
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <!-- <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    /> -->

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="{{asset('/assets/vendor/fonts/boxicons.css')}}" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="{{ asset('/assets/vendor/css/core.css')}}" class="template-customizer-core-css" />
    <link rel="stylesheet" href="{{ asset('/assets/vendor/css/theme-default.css')}}" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="{{ asset('/assets/css/demo.css')}}" />
    <link rel="stylesheet" href="{{ asset('/assets/css/counter.css') }}">
    <!-- Add these links to your HTML file or layout file -->

    <!-- Data Tables -->

<style>
.bg-menu-theme .menu-inner > .menu-item.active > .menu-link {
    background-color: #81CECA !important;
    color: #fff !important;
}

.bg-menu-theme .menu-inner > .menu-item.active > .menu-link i {
    color: #fff !important;
}
</style>

<style>
/* Primary buttons */
.btn-primary {
    background-color: #81CECA !important;
    border-color: #81CECA !important;
    color: #fff !important;
}

/* Outline buttons */
.btn-outline-primary {
    color: #81CECA !important;
    border-color: #81CECA !important;
}

.btn-outline-primary:hover {
    background-color: #81CECA !important;
    color: #fff !important;
}

/* Text primary */
.text-primary {
    color: #81CECA !important;
}

/* Background labels / badges */
.bg-label-primary {
    background-color: #81CECA !important;
    color: #fff !important;
}

/* Solid badges */
.bg-primary {
    background-color: #81CECA !important;
}

/* Icons */
.text-primary i,
.menu-icon.text-primary {
    color: #81CECA !important;
}

/* Links */
a.text-primary {
    color: #81CECA !important;
}

/* Dropdown active / focus */
.dropdown-item:active {
    background-color: #81CECA !important;
}

/* Pagination / datatable (optional) */
.page-item.active .page-link {
    background-color: #81CECA !important;
    border-color: #81CECA !important;
}

.app-brand .layout-menu-toggle {
    background-color: #81CECA !important; /* desired background */
    border: 7px solid #f5f5f9 !important;   /* desired border */
    color: #000 !important;                 /* optional: text/icon color */
    transition: background-color 0.3s, border-color 0.3s !important; /* smooth effect */
}

.app-brand .layout-menu-toggle:hover {
    background-color: #81CECA !important; /* slightly darker on hover */
    border-color: #e0e0e0 !important;     /* optional hover border */
}

</style>




    <!-- Vendors CSS -->
    <link rel="stylesheet" href="{{ asset('/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css')}}" />

    <!-- Page CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bs-stepper/dist/css/bs-stepper.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/bs-stepper/dist/js/bs-stepper.min.js"></script>

    <!-- Helpers -->
    <script src="{{ asset('/assets/vendor/js/helpers.js')}}"></script>


    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="{{ asset('/assets/js/config.js')}}"></script>

  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

        <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <div class="app-brand demo" style="height:90px; overflow:hidden;">

    <a href="#" class="app-brand-link"
       style="display:flex; justify-content:center; align-items:center; height:100%;">

        <img src="{{ asset('newdes/zindgi.png') }}"
             alt="Your Logo"
             style="max-height:80px; max-width:100%; object-fit:contain;">
    </a>

    <a href="javascript:void(0);"
       class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
        <i class="bx bx-chevron-left bx-sm align-middle"></i>
    </a>

</div>
          <div class="menu-inner-shadow"></div>

          <li class="menu-header small text-uppercase"><span class="menu-header-text">Side MenuBar</span></li>
          <ul class="menu-inner py-1">
            <!-- Dashboard -->
            <li class="menu-item {{ Request::is('basic-agent-l/dashboard') ? 'active' : '' }}">
              <a href="{{ route('basic-agent-l.dashboard') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                <div data-i18n="Analytics">Dashboard</div>
              </a>
            </li>

            <li class="menu-header small text-uppercase"><span class="menu-header-text">Insurance Products</span></li>
            <!-- Cards -->
            <li class="menu-item {{ Request::is('basic-agent-l/sales') ? 'active' : '' }}
            {{ Request::is('basic-agent-l/transaction') ? 'active' : '' }}
            ">
              <a href="{{ route('basic-agent-l.sales') }}" id = "salespagebutton" class="menu-link">
                <i class="menu-icon tf-icons bx bx-collection"></i>
                <div data-i18n="Basic">Start Sales</div>
              </a>
            </li>
            <li class="menu-header small text-uppercase"><span class="menu-header-text">Payment Process</span></li>
            <!-- Cards -->
            <li class="menu-item {{ Request::is('basic-agent-l/auto/debit/index') ? 'active' : '' }}">
                <a href="{{ route('basic-agent-l.index') }}" id = "salespagebutton" class="menu-link">
                  <i class="menu-icon tf-icons bx bx-collection"></i>
                  <div data-i18n="Basic">Auto Debit</div>
                </a>
              </li>


            <!-- Layouts -->

             <!-- Information -->
             <li class="menu-header small text-uppercase"><span class="menu-header-text">Information</span></li>
             <li class="menu-item {{ Request::is('basic-agent-l/customer/info') ? 'active' : '' }}">
                 <a href="{{ route('basic-agent-l.customerinformation') }}" class="menu-link">
                   <i class="menu-icon tf-icons bx bx-collection"></i>
                   <div data-i18n="Basic">Customer Information</div>
                 </a>
               </li>
                       <!-- Components -->
            <li class="menu-header small text-uppercase"><span class="menu-header-text">Sales Information</span></li>
            <!-- Cards -->
            <li class="menu-item {{ Request::is('basic-agent-l/sucesssales') ? 'active' : '' }}">
              <a href="{{ route('basic-agent-l.sucesssales') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-collection"></i>
                <div data-i18n="Basic">Confirm Sales</div>
              </a>
            </li>
            <li class="menu-item {{ Request::is('basic-agent-l/Failedsucesssales') ? 'active' : '' }}">
              <a href="{{ route('basic-agent-l.Failedsucesssales') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-file"></i>
                <div data-i18n="Basic">Failed Sales</div>
              </a>
            </li>
            <!-- User interface -->

            {{-- <li class="menu-header small text-uppercase"><span class="menu-header-text">Performance</span></li> --}}
            <!-- Forms -->
            {{-- <li class="menu-item {{ Request::is('basic-agent-l/overall-reports') ? 'active' : '' }}">
              <a href="{{ route('basic-agent-l.overall-reports') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-collection"></i>
                <div data-i18n="Basic">Overall Sales Score</div>
              </a>
            </li> --}}
            <!-- Misc -->

          </ul>
        </aside>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->

          <nav
            class="layout-navbar container-fluid navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
            id="layout-navbar"
          >
            <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
              <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                <i class="bx bx-menu bx-sm"></i>
              </a>
            </div>

            <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
              <!-- Search -->
              <div class="navbar-nav align-items-center">
                <div class="nav-item d-flex align-items-center">
                  <i class="bx bx-search fs-4 lh-0"></i>
                  <input
                    type="text"
                    class="form-control border-0 shadow-none"
                    placeholder="Search..."
                    aria-label="Search..."
                  />
                </div>
              </div>
              <!-- /Search -->

              <ul class="navbar-nav flex-row align-items-center ms-auto">
                <!-- Place this tag where you want the button to render. -->
               <li class="nav-item lh-1 me-3">
  <a
    class="github-button"
    href="#"
    style="background-color:#81CECA; border:1px solid #81CECA; color:#fff; padding:5px 10px; display:inline-block; border-radius:4px; text-decoration:none;"
    onmouseover="this.style.backgroundColor='#6bbab6'; this.style.borderColor='#6bbab6';"
    onmouseout="this.style.backgroundColor='#81CECA'; this.style.borderColor='#81CECA';"
    aria-label=""
  >
    Agent Name: {{ session('agent')->first_name }}
  </a>
</li>

                <!-- User -->
                <li class="nav-item navbar-dropdown dropdown-user dropdown">
                  <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                    <div class="avatar avatar-online">
                      <img src="{{ asset('/assets/img/avatars/1.png')}}" alt class="w-px-40 h-auto rounded-circle" />
                    </div>
                  </a>
                  <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                      <a class="dropdown-item" href="#">
                        <div class="d-flex">
                          <div class="flex-shrink-0 me-3">
                            <div class="avatar avatar-online">
                              <img src="{{asset('/assets/img/avatars/1.png')}}" alt class="w-px-40 h-auto rounded-circle" />
                            </div>
                          </div>
                          <div class="flex-grow-1">
                            <span class="fw-semibold d-block">{{ session('agent')->first_name }}</span>
                            <small class="text-muted">Marketing Captain</small>
                          </div>
                        </div>
                      </a>
                    </li>
                    <li>
                      <div class="dropdown-divider"></div>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        <i class="bx bx-user me-2"></i>
                        <span class="align-middle">My Profile</span>
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        <i class="bx bx-cog me-2"></i>
                        <span class="align-middle">Settings</span>
                      </a>
                    </li>

                    <li>
                      <div class="dropdown-divider"></div>
                    </li>
                    <li>
                      <a class="dropdown-item" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" href="#">
                        <i class="bx bx-power-off me-2"></i>
                        <span class="align-middle">Log Out</span>
                      </a>
                    </li>

                  </ul>
                </li>

<form id="logout-form" action="{{ route('basic-agent-l.logout') }}" method="POST" style="display: none;">
    @csrf
</form>
                <!--/ User -->
              </ul>
            </div>
          </nav>

          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-fluid flex-grow-1 container-p-y">
              <!-- Layout Demo -->
              <div class="">
                <div class="">

                <!-- Here we Have to Put our Things Jahangir khan  -->

                <!-- Start -->

                @yield('content')

                <!-- End -->

              <!-- Buttons -->

            </div>



          </div>
        </div>
              <!--/ Layout Demo -->
            </div>
            <!-- / Content -->

            <!-- Footer -->
            <footer class="content-footer footer bg-footer-theme">
              <div class="container-fluid d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                <div class="mb-2 mb-md-0">
                  ©
                  <script>
                    document.write(new Date().getFullYear());
                  </script>
                  , Developed By
                  <a href="https://www.efulife.com" target="_blank" class="footer-link fw-bolder">EFU LIFE Tech Team</a>
                </div>
                <div>
                  <a href="#" class="footer-link me-4" target="_blank">License</a>


                  <a
                    href="#"
                    target="_blank"
                    class="footer-link me-4"
                    >Support</a
                  >

                  <a
                    href="#"
                    target="_blank"
                    class="footer-link me-4"
                    >Support</a
                  >
                </div>
              </div>
            </footer>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->

    <div class="buy-now">
      <a
        href="#"
        target="_blank"
        class="btn btn-danger btn-buy-now"
        >Contact IT Support </a
      >
    </div>

     <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="//cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <!-- <script src="{{asset ('/assets/vendor/libs/jquery/jquery.js')}}"></script> -->
    <script src="{{asset ('/assets/vendor/libs/popper/popper.js')}}"></script>
    <script src="{{asset ('/assets/vendor/js/bootstrap.js')}}"></script>
    <script src="{{asset ('/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js')}}"></script>

    <script src="{{asset ('/assets/vendor/js/menu.js')}}"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->
    <script src="{{asset ('/assets/js/main.js')}}"></script>

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
    <!-- <script async defer src="https://buttons.github.io/buttons.js"></script> -->




  <script>
  let table = new DataTable('#subscription');
  </script>

  @stack('scripts')

  </body>
</html>
