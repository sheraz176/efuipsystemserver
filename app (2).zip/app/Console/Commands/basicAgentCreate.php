<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\TeleSalesAgent;
use App\Models\Company\CompanyProfile;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Response;

class basicAgentCreate extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'basicagent:create';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Basic Agent Ids Create';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {


$agentsData = [
    ['Aseer', 'Abbas', 'aseer.abbas.sybrid', 'Aseer#Abbas##sybrid#2026', 'aseerabbasbhatti@gmail.com'],
    ['Ali', 'Razatwo', 'alitwo.raza.sybrid', 'Alitwo#Raza##sybrid#2026', 'alitwoabbasi557766@gmail.com'],
    ['Ramsha', 'Zarvaiz', 'ramsha.zarvaiz.sybrid', 'Ramsha#Zarvaiz##sybrid#2026', 'awanramsha46@gmail.com'],
    ['Qurat Ul', 'Ain', 'quratul.ain.sybrid', 'QuratUl#Ain##sybrid#2026', 'sardarm795@gmail.com'],
    ['Laiba', 'Touseef', 'laiba.touseef.sybrid', 'Laiba#Touseef##sybrid#2026', 'laibaashir870@gmail.com'],
    ['Zohaib', 'Abbasi', 'zohaib.abbasi.sybrid', 'Zohaib#Abbasi##sybrid#2026', 'abbasizohaib75@gmail.com'],
    ['Khansa', 'Karim', 'khansa.karim.sybrid', 'Khansa#Karim##sybrid#2026', 'khansamalik138@gmail.com'],
    ['Tania', 'Khalid', 'tania.khalid.sybrid', 'Tania#Khalid##sybrid#2026', 'taniakhalid100@gmail.com'],
    ['Sadaf', 'Ishtiaq', 'sadaf.ishtiaq.sybrid', 'Sadaf#Ishtiaq##sybrid#2026', 'muhammadhassan5858@gmail.com'],
    ['Muhammad', 'Khalil', 'muhammad.khalil.sybrid', 'Muhammad#Khalil##sybrid#2026', 'km7505138@gmail.com'],
    ['Muhammad Hamid', 'Younas', 'muhammadhamid.younas.sybrid', 'MuhammadHamid#Younas##sybrid#2026', 'hamid.younas1243@gmail.com'],
    ['Usama', 'Nazir', 'usama.nazir.sybrid', 'Usama#Nazir##sybrid#2026', 'usamanazir088@gmail.com'],
    ['Muhammad', 'Shafiq', 'muhammad.shafiq.sybrid', 'Muhammad#Shafiq##sybrid#2026', 'muhammadshafeeq7865@gmail.com'],
    ['Arshad', 'Mehmood', 'arshad.mehmood.sybrid', 'Arshad#Mehmood##sybrid#2026', 'arshadgujrati593@gmail.com'],
    ['Muhammad', 'Ali', 'muhammad.ali.sybrid', 'Muhammad#Ali##sybrid#2026', 'alikashmiri879@gmail.com'],
    ['Munawar', 'Waheed', 'munawar.waheed.sybrid', 'Munawar#Waheed##sybrid#2026', 'rajamunawar2772@gmail.com'],
    ['Raja', 'Umair', 'raja.umair.sybrid', 'Raja#Umair##sybrid#2026', 'rajaumair331@gmail.com'],
    ['Ainee', 'two', 'ainee.sybrid', 'Ainee##sybrid#2026', 'aineeawan153@gmail.com'],
    ['Sawaira', 'Nawaz', 'sawaira.nawaz.sybrid', 'Sawaira#Nawaz##sybrid#2026', 'sawairanawaz100@gmail.com'],
    ['Noshaba', 'Nawaz', 'noshaba.nawaz.sybrid', 'Noshaba#Nawaz##sybrid#2026', 'noshabanawaz@gmail.com'],
    ['Muhammad Taha', 'Khan', 'muhammadtaha.khan.sybrid', 'MuhammadTaha#Khan##sybrid#2026', 'mtahakhan018@gmail.com'],
    ['Raja Umair', 'Wasif', 'rajaumair.wasif.sybrid', 'RajaUmair#Wasif##sybrid#2026', 'rajaumairali.001@gmail.com'],
];

        foreach ($agentsData as $data) {
            $request = [
                'first_name' => $data[0],
                'last_name' => $data[1],
                'username' => $data[2],
                'email' => $data[4],
                'status' => 1,
                'company_id' => 12,
                'password' => $data[3],
            ];

            $validator = Validator::make($request, [
                'first_name' => 'required',
                'last_name' => 'required',
                'username' => 'required|unique:tele_sales_agents',
                'email' => 'required|email|unique:tele_sales_agents',
                'status' => 'required|in:1,0',
                'company_id' => 'required',
                'password' => 'required|min:6',
            ]);

            if ($validator->fails()) {
                $this->error("Validation failed for: " . $request['username']);
                continue;
            }

            $validatedData = $validator->validated();
            $validatedData['islogin'] = 0;
            $validatedData['call_status'] = false;
            $validatedData['password'] = Hash::make($request['password']);
            $validatedData['today_login_time'] = now();
            $validatedData['today_logout_time'] = now();

            TelesalesAgent::create($validatedData);

            $this->info("Created Telesales Agent: " . $request['username']);
        }

        return 0;
    }
}
